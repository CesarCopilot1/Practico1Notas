package com.example.listapersonas.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.example.listapersonas.R
import com.example.listapersonas.models.Nota

class NotaAdapter(
    private val notaList: ArrayList<Nota>,
    private val listener: OnNotaClickListener
) : RecyclerView.Adapter<NotaAdapter.NotaViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NotaViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.nota_item_layout, parent, false)
        return NotaViewHolder(view)
    }

    override fun getItemCount(): Int = notaList.size

    override fun onBindViewHolder(holder: NotaViewHolder, position: Int) {
        holder.bind(notaList[position], listener)
    }

    fun itemAdded(nota: Nota) {
        notaList.add(0, nota)
        notifyItemInserted(0)
    }

    fun itemDeleted(nota: Nota) {
        val index = notaList.indexOf(nota)
        if (index >= 0) {
            notaList.removeAt(index)
            notifyItemRemoved(index)
        }
    }

    fun itemUpdated(nota: Nota) {
        val index = notaList.indexOf(nota)
        if (index >= 0) {
            notaList[index] = nota
            notifyItemChanged(index)
        }
    }

    class NotaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val titulo = itemView.findViewById<TextView>(R.id.lblNotaTitulo)
        private val texto = itemView.findViewById<TextView>(R.id.lblNotaTexto)
        private val cardView = itemView.findViewById<CardView>(R.id.cardNota)
        private val btnEdit = itemView.findViewById<ImageButton>(R.id.btnEditNota)
        private val btnDelete = itemView.findViewById<ImageButton>(R.id.btnDeleteNota)

        fun bind(nota: Nota, listener: OnNotaClickListener) {
            titulo.text = nota.Titulo
            texto.text = nota.Texto
            cardView.setCardBackgroundColor(nota.Color.toArgb())

            btnEdit.setOnClickListener {
                listener.onNotaEditClickListener(nota)
            }
            btnDelete.setOnClickListener {
                listener.onNotaDeleteClickListener(nota)
            }
        }
    }

    interface OnNotaClickListener {
        fun onNotaEditClickListener(nota: Nota)
        fun onNotaDeleteClickListener(nota: Nota)
    }
}
