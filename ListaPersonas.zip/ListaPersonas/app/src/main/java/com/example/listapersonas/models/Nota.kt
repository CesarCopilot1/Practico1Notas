package com.example.listapersonas.models

import android.graphics.Color

data class Nota(
    var Titulo: String,
    var Texto: String,
    var Estado: Boolean,
    var Color: Color

)
