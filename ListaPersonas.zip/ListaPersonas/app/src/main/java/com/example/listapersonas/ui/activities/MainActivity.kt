package com.example.listapersonas.ui.activities

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.toColor
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.listapersonas.R
import com.example.listapersonas.models.Nota
import com.example.listapersonas.ui.adapters.NotaAdapter
import com.google.android.material.floatingactionbutton.FloatingActionButton
//import kotlin.coroutines.jvm.internal.CompletedContinuation.context

class MainActivity : AppCompatActivity(), NotaAdapter.OnNotaClickListener {

    private val notaList = arrayListOf(
        Nota("Recordar", "Hacer la compra", true, Color.YELLOW.toColor()),
        Nota("Estudiar", "Repasar Kotlin", false, Color.CYAN.toColor())
    )

    private lateinit var rvNotaList: RecyclerView
    private lateinit var fabAddNota: FloatingActionButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        fabAddNota = findViewById(R.id.fabAddContact) // Puedes renombrar el id si quieres a fabAddNota
        rvNotaList = findViewById(R.id.rvContactList) // Igual, podrías cambiar id a rvNotaList

        setupRecyclerView()
        setupEventListeners()
    }

    private fun setupEventListeners() {
        fabAddNota.setOnClickListener {
            buildNotaDialog()
        }
    }

    private fun setupRecyclerView() {
        rvNotaList.adapter = NotaAdapter(notaList, this)
        rvNotaList.layoutManager = LinearLayoutManager(this).apply {
            orientation = LinearLayoutManager.VERTICAL
        }
    }

    private fun buildNotaDialog(nota: Nota? = null) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Formulario de nota")

        val viewInflated: View = LayoutInflater.from(this).inflate(R.layout.form_nota_layout, null, false)

        val txtTitulo: EditText = viewInflated.findViewById(R.id.txtNotaTitulo)
        val txtTexto: EditText = viewInflated.findViewById(R.id.txtNotaTexto)
        val spinnerNotaColor: Spinner = viewInflated.findViewById(R.id.spinnerNotaColor)
        val colorSeleccionado: String = spinnerNotaColor.selectedItem.toString()

        val txtColor: EditText = EditText(baseContext)
        txtColor.setText(colorSeleccionado) // Correcto


        txtTitulo.setText(nota?.Titulo)
        txtTexto.setText(nota?.Texto)
        txtColor.setText(nota?.Color?.toArgb()?.let { String.format("#%06X", 0xFFFFFF and it) })

        builder.setView(viewInflated)

        builder.setPositiveButton(android.R.string.ok) { dialog, _ ->
            dialog.dismiss()
            val titulo = txtTitulo.text.toString()
            val texto = txtTexto.text.toString()
            val spinnerNotaColor: Spinner = viewInflated.findViewById(R.id.spinnerNotaColor)
            val colorSeleccionado: String = spinnerNotaColor.selectedItem?.toString() ?: "#FFFFFF"


            val txtColor: EditText = EditText(baseContext)
            txtColor.setText(colorSeleccionado) // Correcto
            val colorTexto = txtColor.text.toString()

            if (titulo.isBlank() || texto.isBlank() || colorTexto.isBlank()) {
                Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show()
                return@setPositiveButton
            }

            val color = try {
                Color.valueOf(Color.parseColor(colorTexto))
            } catch (e: IllegalArgumentException) {
                Toast.makeText(this, "Color inválido", Toast.LENGTH_SHORT).show()
                return@setPositiveButton
            }

            if (nota != null) {
                nota.Titulo = titulo
                nota.Texto = texto
                nota.Color = color
                editNota(nota)
            } else {
                addNota(Nota(titulo, texto, false, color))
            }
        }

        builder.setNegativeButton(android.R.string.cancel) { dialog, _ ->
            dialog.cancel()
        }

        builder.show()
    }

    private fun addNota(nota: Nota) {
        val adapter = rvNotaList.adapter as NotaAdapter
        adapter.itemAdded(nota)
    }

    private fun editNota(nota: Nota) {
        val adapter = rvNotaList.adapter as NotaAdapter
        adapter.itemUpdated(nota)
    }

    override fun onNotaEditClickListener(nota: Nota) {
        buildNotaDialog(nota)
    }

    override fun onNotaDeleteClickListener(nota: Nota) {
        val adapter = rvNotaList.adapter as NotaAdapter
        adapter.itemDeleted(nota)
    }
}
