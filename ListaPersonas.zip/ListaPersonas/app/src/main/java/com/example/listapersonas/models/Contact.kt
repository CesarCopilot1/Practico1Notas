package com.example.listapersonas.models

data class Contact(
    var name: String,
    var phone: String
)